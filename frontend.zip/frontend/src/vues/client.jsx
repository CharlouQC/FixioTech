import React, { useEffect, useMemo, useState } from "react";
import "./client.css";
import { useAuth } from "../context/AuthContext";
import { getRendezVousByClient } from "../../services/apiRendezVous";
import { getEmployes } from "../../services/apiUtilisateur";

const Client = () => {
  const { user, role } = useAuth();

  const [loading, setLoading] = useState(true);
  const [rdvs, setRdvs] = useState([]);
  const [error, setError] = useState("");

  // { [id]: { id, nom_complet, email, ... } }
  const [employesMap, setEmployesMap] = useState({});

  // Formatage simple des dates
  const fmtDate = (isoDate) => {
    // Si backend renvoie "YYYY-MM-DD", l'afficher tel quel (évite les décalages de fuseau)
    if (/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) return isoDate;
    try {
      const d = new Date(isoDate);
      if (Number.isNaN(d.getTime())) return isoDate;
      return d.toLocaleDateString();
    } catch {
      return isoDate;
    }
  };

  useEffect(() => {
    let cancelled = false;

    // Si l'utilisateur n'est pas prêt, sortir proprement
    if (!user?.id) {
      setLoading(false);
      return;
    }

    async function load() {
      setLoading(true);
      setError("");

      try {
        // Charger en parallèle RDV + employés
        const [rdvList, employes] = await Promise.all([
          getRendezVousByClient(user.id),
          getEmployes(),
        ]);

        if (cancelled) return;

        // Met à jour les RDV
        setRdvs(Array.isArray(rdvList) ? rdvList : []);

        // Construire la map employé -> objet
        const map = {};
        (Array.isArray(employes) ? employes : []).forEach((e) => {
          if (e?.id != null) map[e.id] = e;
        });
        setEmployesMap(map);
      } catch (err) {
        if (cancelled) return;
        setError(err?.message ? err.message : String(err));
        setRdvs([]);
        setEmployesMap({});
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const contenu = useMemo(() => {
    if (loading) {
      return (
        <div className="client-loading">Chargement de vos rendez-vous…</div>
      );
    }
    if (error) {
      return <div className="client-error">{error}</div>;
    }
    if (!rdvs.length) {
      return (
        <div className="client-empty">
          Vous n’avez pas encore de rendez-vous.
        </div>
      );
    }

    return (
      <div className="client-rdv-liste">
        {rdvs.map((r) => {
          const tech = employesMap[r.employe_id];
          const techLabel =
            tech?.nom_complet || tech?.email || `Technicien #${r.employe_id}`;

          return (
            <div key={r.id} className="client-rdv-card">
              <div className="client-rdv-header">
                <div className="client-rdv-id">RDV #{r.id}</div>
                <div
                  className={`client-statut-badge client-statut-${(
                    r.statut || "Programmé"
                  ).toLowerCase()}`}
                >
                  {r.statut || "Programmé"}
                </div>
              </div>

              <div className="client-rdv-body">
                <div className="client-rdv-row">
                  <div className="client-rdv-item">
                    <div className="label">Date</div>
                    <div className="value">{fmtDate(r.date_rdv)}</div>
                  </div>
                  <div className="client-rdv-item">
                    <div className="label">Heure</div>
                    <div className="value">{r.heure_rdv || "—"}</div>
                  </div>
                </div>

                <div className="client-rdv-row">
                  <div className="client-rdv-item">
                    <div className="label">Technicien assigné</div>
                    <div className="value">{techLabel}</div>
                  </div>
                </div>

                {r.description_probleme ? (
                  <div className="client-rdv-desc">
                    <div className="label">Description</div>
                    <p className="value">{r.description_probleme}</p>
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    );
  }, [loading, error, rdvs, employesMap]);

  return (
    <div className="client-container">
      <div className="client-header">
        <h1>Mes demandes</h1>
        <p className="client-intro">
          Consultez ici vos rendez-vous demandés et leur statut.
        </p>
      </div>

      {contenu}
    </div>
  );
};

export default Client;
